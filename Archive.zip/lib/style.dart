
import 'package:flutter/material.dart';

InputDecoration myfieldStyle(label){
  return InputDecoration(
    border: OutlineInputBorder(),
    labelText: label,
    contentPadding: EdgeInsets.all(10),
  );
}

